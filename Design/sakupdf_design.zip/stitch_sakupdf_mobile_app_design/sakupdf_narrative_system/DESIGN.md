---
name: SakuPDF Narrative System
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3d4946'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#6d7a77'
  outline-variant: '#bcc9c5'
  surface-tint: '#006b5f'
  primary: '#00685d'
  on-primary: '#ffffff'
  primary-container: '#008376'
  on-primary-container: '#f4fffb'
  inverse-primary: '#70d8c8'
  secondary: '#516161'
  on-secondary: '#ffffff'
  secondary-container: '#d4e6e5'
  on-secondary-container: '#576867'
  tertiary: '#b7131a'
  on-tertiary: '#ffffff'
  tertiary-container: '#db322f'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#8df5e4'
  primary-fixed-dim: '#70d8c8'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005048'
  secondary-fixed: '#d4e6e5'
  secondary-fixed-dim: '#b8cac9'
  on-secondary-fixed: '#0e1e1e'
  on-secondary-fixed-variant: '#3a4a49'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ac'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#93000d'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 57px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
  title-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.15px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.5px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.25px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.1px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.5px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base_unit: 8px
  margin-mobile: 16px
  margin-tablet: 24px
  gutter: 16px
  touch-target-min: 48px
---

## Brand & Style
The design system for this privacy-focused Android PDF utility prioritizes clarity, trust, and professional efficiency. It adopts a **Corporate / Modern** style heavily influenced by Material 3 principles, ensuring the interface feels native to the Android ecosystem while maintaining a distinct, friendly character. 

The aesthetic is defined by high legibility, ample whitespace, and soft structural elements that reduce the perceived complexity of document management. The "Saku" (pocket) concept is reflected in a compact, organized, and readily accessible UI that empowers users to handle sensitive documents with confidence.

## Colors
The palette utilizes a sophisticated Emerald/Teal as the primary brand anchor, signaling growth and security. 

- **Primary & Container:** Use #00897B for core actions and #E0F2F1 for large background areas of interactive components to maintain a "Pale Mint" freshness.
- **Surface Strategy:** The background uses a soft off-white (#F8F9FA) to reduce eye strain, while pure white (#FFFFFF) is reserved for elevated cards and modals.
- **Typography:** Primary information uses a deep Dark Navy (#1A237E) to ensure high contrast and a premium feel, departing from standard pitch black.
- **Semantic Accents:** A muted red (#E53935) is used sparingly as the "PDF Accent" to signify document-specific status or traditional PDF branding without triggering "error" fatigue.

## Typography
This design system employs **Inter** for its exceptional legibility and neutral, systematic tone. The type scale follows the Material 3 "Type System" to ensure hierarchy is immediate and clear.

- **Language Support:** All UI copy is in **Indonesian**. Headlines should use sentence case (e.g., "Semua dokumen").
- **Hierarchy:** Use `title-lg` for Top App Bar titles and `body-lg` for primary document lists.
- **Reading Comfort:** `body-md` is the standard for metadata and secondary descriptions, ensuring a balance between information density and readability.

## Layout & Spacing
The layout is built on a strict **8dp grid** system, ensuring mathematical harmony across all components.

- **Margins & Gutters:** Mobile screens must maintain a 16dp outer margin. Internal gutters between cards or list items should be 8dp or 16dp depending on content density.
- **Touch Targets:** All interactive elements (buttons, icons, checkboxes) must have a minimum hit area of 48x48dp to ensure accessibility for all users.
- **Structure:** Use a single-column layout for mobile document lists. On tablets, transition to a multi-column grid (2-3 columns) for document previews.

## Elevation & Depth
The system uses **Tonal Layers** rather than heavy drop shadows to define hierarchy, aligned with the latest Android evolution.

- **Level 0 (Background):** Soft off-white (#F8F9FA). Flat.
- **Level 1 (Cards/Surface):** Pure White (#FFFFFF). Uses a very subtle, diffused shadow (blur: 4dp, alpha: 0.05) or a 1dp light grey stroke to distinguish from the background.
- **Level 2 (Modals/Menus):** Slight elevation with a more pronounced shadow to indicate temporary overlay.
- **Scrolled State:** Top App Bars should gain a tonal tint (#E0F2F1) when content scrolls beneath them.

## Shapes
The shape language is "Rounded" to evoke a friendly and approachable tool. 

- **Cards & Containers:** Use a corner radius of **16dp** for standard document cards and **20dp** for larger bottom sheets or modal dialogs.
- **Buttons:** Primary buttons should be fully rounded (Pill-shaped) to clearly distinguish them from informational cards.
- **Inputs:** Text fields should use the Material Outlined style with an 8dp corner radius.

## Components
Consistent implementation of these components ensures a cohesive experience:

- **Top App Bars:** Centered or left-aligned title (`title-lg`). Use "Outlined" style icons for actions like "Search" or "Settings."
- **Bottom Navigation:** Three to five destinations (e.g., *Beranda, Berkas, Alat, Pengaturan*). Active states use a Teal pill shape behind the icon.
- **Primary Action Button (FAB):** A sticky or floating button for "Add/Scan" tasks. Use the Primary color (#00897B) with a white icon.
- **Document Cards:** White surface, 16dp radius. Include a thumbnail, filename (`title-md`), and metadata (`label-sm`).
- **Input Fields:** Outlined with #757575 borders, shifting to #00897B on focus. Labels should be clear and in Indonesian.
- **Chips:** Used for filtering document types (PDF, Image, Doc). Use the Primary Container (#E0F2F1) for selected states.